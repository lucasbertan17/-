volatile char *UART0DR = (char *)0x101f1000;

void new_putchar(char c) {
    *UART0DR = c;
}

int getchar() {
    return 0;
}

void main() {
    static char memory[3000] = {0};
    // const char *program = "++++++++++++++++++++++++++++++++++."; // #
    // const char *program = "+[,.]";
    const char *program = "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++.>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.------.--------.>+.>."; // Hello World!

    int pos_memoria = 0;
    for (int i = 0; program[i] != '\0'; i++) {
        switch (program[i]) {
            case '>': ++pos_memoria; break;
            case '<': --pos_memoria; break;
            case '+': ++memory[pos_memoria]; break;
            case '-': --memory[pos_memoria]; break;
            case '.': new_putchar(memory[pos_memoria]); break;
            case ',': memory[pos_memoria] = getchar(); break;
            case '[':
                if (!memory[pos_memoria]) {
                    int loop = 1;
                    while (loop > 0) {
                        i++;
                        if (program[i] == '[') loop++;
                        else if (program[i] == ']') loop--;
                    }
                }
                break;
            case ']':
                if (memory[pos_memoria]) {
                    int loop = 1;
                    while (loop > 0) {
                        i--;
                        if (program[i] == ']') loop++;
                        else if (program[i] == '[') loop--;
                    }
                    i--; // desfaz incremento do for
                }
                break;
        }
    }

    while (1);
}
