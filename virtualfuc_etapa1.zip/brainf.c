#include <stdio.h>

void run_bf(const char *code, char *memory, int (*getchar)(), void (*new_putchar)(char), int n) {
    const char *pc = code;
    char *ptr = memory;

    printf("comeco");
    while (*pc) {
        switch (*pc) {
            case '>': ++ptr; break;
            case '<': --ptr; break;
            case '+': ++*ptr; printf("+"); break;
            case '-': --*ptr; break;
            case '.': new_putchar(*ptr); break;
            case ',': *ptr = getchar(); break;
            case '[':
                if (!*ptr) {
                    int loop = 1;
                    while (loop > 0) {
                        ++pc;
                        if (*pc == '[') ++loop;
                        else if (*pc == ']') --loop;
                    }
                }
                break;
            case ']':
                if (*ptr) {
                    int loop = 1;
                    while (loop > 0) {
                        --pc;
                        if (*pc == '[') --loop;
                        else if (*pc == ']') ++loop;
                    }
                }
                break;
        }
        ++pc;
    }
}
